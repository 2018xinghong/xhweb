<template>
  <editor />
</template>

<script>
import editor from './editor';

export default {
  components: {
    editor
  }
};
</script>
